package Test_Cases;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Todo_App {
	
	public WebDriver driver;

	@BeforeSuite
	public WebDriver launchBrowser() throws IOException {
		String browser="chrome";
		String url="https://todomvc.com/examples/angular/dist/browser/#/all";
		
		if(browser.equalsIgnoreCase("Chrome")) {
			driver=new ChromeDriver();
		}else {
			driver=new FirefoxDriver();
		}
		
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		return driver;
	}
	
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}

	public void addTodo() {
		WebElement todoInput = driver.findElement(By.xpath("//input[@class='new-todo ng-pristine ng-valid ng-touched']")); 
		todoInput.sendKeys("Drink Water Every Hour"); 
		todoInput.sendKeys(Keys.ENTER);
	}
	public void checkBox_Click() {
		WebElement checkbox = driver.findElement(By.xpath("//input[@class='toggle']")); 
		checkbox.click();
	}
	@Test 
	public void testAddTodo() {
			addTodo();
			List<WebElement> todos = driver.findElements(By.xpath("//ul[@class='todo-list']"));
			Assert.assertTrue(todos.stream().anyMatch(todo -> todo.getText().contains("Drink Water Every Hour"))); 
		} 
	
	
	
	@Test(dependsOnMethods = "testAddTodo") 
	public void testMarkTodoAsComplete() { 
			checkBox_Click();
			WebElement completedItem = driver.findElement(By.cssSelector(".todo-list li.completed")); 
			Assert.assertNotNull(completedItem); 
			WebElement counter = driver.findElement(By.cssSelector(".todo-count")); 
			Assert.assertTrue(counter.getText().contains("0 items left")); 
		} 
	
	
	@Test(dependsOnMethods = "testFilterTodo") 
	public void testDeleteTodo() { 
			WebElement deleteButton = driver.findElement(By.cssSelector(".todo-list li .destroy")); 
			deleteButton.click(); 
			List<WebElement> todos = driver.findElements(By.cssSelector(".todo-list li")); 
			Assert.assertTrue(todos.isEmpty()); 
		} 
	
	
	
	public void active_Filter() {
			WebElement activeFilter = driver.findElement(By.linkText("Active")); 
			activeFilter.click(); 
			List<WebElement> activeTodos = driver.findElements(By.cssSelector(".todo-list li")); 
			Assert.assertTrue(activeTodos.isEmpty());
	}
	public void completed_Filter() {
			WebElement completedFilter = driver.findElement(By.linkText("Completed")); 
			completedFilter.click(); 
			List<WebElement> completedTodos = driver.findElements(By.cssSelector(".todo-list li")); 
			Assert.assertTrue(completedTodos.stream().anyMatch(todo -> todo.getText().contains("Drink Water Every Hour")));
	}
	@Test(dependsOnMethods = "testMarkTodoAsComplete") 
	public void testFilterTodo() { 
			active_Filter(); 
			completed_Filter(); 
		} 

}
